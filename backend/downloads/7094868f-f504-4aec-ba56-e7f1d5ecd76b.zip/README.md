## Run the Vision Pipeline

### Install dependencies
pip install -r requirements.txt

### Run
python run.py path/to/image.jpg
