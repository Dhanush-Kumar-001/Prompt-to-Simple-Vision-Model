from ultralytics import YOLO
import sys
import cv2
from pathlib import Path

def main():
    if len(sys.argv) < 2:
        print("Usage: python run.py <image_path>")
        return

    image_path = sys.argv[1]

    if not Path(image_path).exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    model = YOLO("yolov8n-seg.pt")

    results = model(
        image_path,
        classes=[0],
        conf=0.25
    )

    # --- Segmentation capability ---
    detections = results[0]
    masks = results[0].masks

    # --- Output: bounding boxes ---
    annotated = detections.plot()
    output_path = "output.jpg"
    cv2.imwrite(output_path, annotated)
    print(f"Saved detection output to {output_path}")

if __name__ == "__main__":
    main()